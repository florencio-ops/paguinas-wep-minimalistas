<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<HEAD>
   <TITLE>PHP y HTML</TITLE>
   <LINK REL="stylesheet" TYPE="text/css" HREF="estilo.css">
</HEAD>

<BODY>

<H1>PHP y HTML</H1>

<P>Éste es el párrafo 1, escrito desde HTML</P>

<?PHP
   print ("<P>Éste es el párrafo 2, escrito desde PHP</P>\n");
?>

<P>Éste es el párrafo 3, escrito nuevamente desde HTML</P>

<?PHP
   print ("<P>Y éste es el párrafo 4, escrito desde PHP</P>\n");
?>

</BODY>
</HTML>
